/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primenumberchecker;
import java.util.Scanner;
/**
 *
 * @author ALONAJI
 *             *                       
 *            ***                     *****
 *           *****                   ********
 *          *******                 **********
 *         *********               *************
 *       *************           ****************
 ***********WRITTEN BY************BHU/16/04/05/0064**************
 ***********AGADA O.*********************************************
 ***********SOLOMON**********************************************
 *       *************           ****************
 *         *********              **************
 *          *******                ************
 *           *****                  **********
 *            ***                    ********
 *             *                      ******
 */
public class PrimeNumberChecker {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int pnc;
    boolean isPrimeNumber=false;
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Enter a 'NUMBER' ");
    int num=scan.nextInt();
    for(int i=2;i<=num/2;i++)
    {
        pnc=num%i;
        if(pnc==0)
        {
            isPrimeNumber=true;
            break;
        }
    }
        if(isPrimeNumber)
            System.out.println(num + "The number you entered is a 'PRIME NUMBER' ");
        else
            System.out.println(num + "The number you entered is a 'NOT A PRIME NUMBER' ");
    }
    
}
